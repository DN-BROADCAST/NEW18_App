export default {
  container: {
    backgroundColor: "#fff"
  }
};
