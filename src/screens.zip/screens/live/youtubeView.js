import React, { Component } from "react";
import { Image, Platform, Share, Linking, WebView, View, RefreshControl, TouchableOpacity, Dimensions, StatusBar } from "react-native";
import {
  Container,
  Header,
  Content,
  Button,
  Card,
  CardItem,
  Text,
  Left,
  Body,
  Right
} from "native-base";
import styles from "./styles";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import AdComponent from "./Ads";
import TopNews from "./TopNews";
import AdMini from "./AdMini";
import Youtube from "./Youtube";
import Moment from 'react-moment';
import Loading from "../index/loading";

import { FacebookAds, Video, AppLoading } from "expo";
import VideoPlayer from '@expo/videoplayer';
import { FlatList, } from 'react-native-gesture-handler';

const adsManager = new FacebookAds.NativeAdsManager('176150199676781_176150239676777');

class YoutubeView extends Component {
  constructor() {
    super();
    this.state = {
      isReady: false,
      data: [],
      Youtube: [],
      refreshing: false,
      reload: false,
      dataload: [],
      Video : [],
      window: Dimensions.get("window"),
    };
  }

  handler = dims => this.setState(dims);

  getTOP() {
    return fetch('http://newtv.co.th/api/getNewsForMobile.php?top=true')
      .then(response => response.json())
      .then((response) => {
        this.setState({ data: response.data, isReady: false });
        this.getYoutube();
      }).catch((err) => {
        console.log('fetch', err)
      });
  }

  getYoutube() {
    const { params } = this.props.navigation.state;
    var Id = params.itemId;
    if (this.state.reload === true){
      Id = this.state.dataload.itemId;
    }
    var datenow = new Date();
    var daynext = new Date();
    daynext.setDate(daynext.getDate() - 7);
    return fetch('https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=UCkqcPORjgyRMD-twNfuDlog&maxResults=30&order=viewCount&publishedAfter=' + daynext.toISOString() + '&publishedBefore=' + datenow.toISOString() + '&q=&regionCode=th&relevanceLanguage=th&fields=etag%2CeventId%2Citems%2Ckind%2CnextPageToken%2CpageInfo%2CprevPageToken%2CregionCode%2CtokenPagination%2CvisitorId&key=AIzaSyATRR51UPyyfhjZPUXUVZ82fAA4QeVefMU')
      .then(response => response.json())
      .then((response) => {
        this.setState({ Youtube: response.items });
        this.getVideo();
      }).catch((err) => {
        console.log('fetch', err)
      });
  }

  getVideo() {
    const { params } = this.props.navigation.state;
    var Id = params.itemId;
    if (this.state.reload === true){
      Id = this.state.dataload.itemId;
    }
    return fetch('http://newtv.co.th/api/youtube/?url=https://www.youtube.com/watch?v=' + Id)
      .then(response => response.json())
      .then((response) => {
        this.setState({ Video: response[0], refreshing: false, isReady: true, reload: false });
        console.log(this.state.Video.url)
      }).catch((err) => {
        console.log('fetch', err)
      });
  }

  componentDidMount() {
    Expo.ScreenOrientation.allow(Expo.ScreenOrientation.Orientation.ALL);
    Dimensions.addEventListener("change", this.handler);
    this.getTOP();
  }

  componentWillUnmount() {
    Expo.ScreenOrientation.allow(Expo.ScreenOrientation.Orientation.PORTRAIT);
    //Expo.ScreenOrientation.allow(Expo.ScreenOrientation.Orientation.ALL);
    Dimensions.removeEventListener("change", this.handler);
  }

  _onRefresh(data) {
    if (data.itemId !== null && data.itemId !== undefined){
      this.setState({reload : true, dataload: data});
    }
    this.setState({ refreshing: true });
    this.getTOP();
  }

  onBannerAdPress = () => console.log('Ad clicked!');
  onBannerAdError = (event) => console.log('Ad error :(', event.nativeEvent);


  render() {
    const { navigate } = this.props.navigation;
    const { width, height } = this.state.window;
    const mode = height > width ? "portrait" : "landscape";
    console.log(`New dimensions ${width}x${height} (${mode})`);
    const { params } = this.props.navigation.state;
    const itemId = params ? params.itemId : null;
    var itemTittle = params ? params.itemTittle : null;
    if (this.state.dataload.itemTittle !== null && this.state.dataload.itemTittle !== undefined){
      var itemTittle = this.state.dataload.itemTittle;
    }
    const videoyoutube = this.state.data.videoyoutube ? this.state.data.videoyoutube : null;
    const customStyle = "<style>* {max-width: 100%;}</style>";
    if (!this.state.isReady) {
      return (
        <Container style={{ backgroundColor: "#282828", }}>
          <Header style={{ backgroundColor: "#282828", }}>
            <StatusBar
              barStyle="light-content"
            />
            <Left>
              <Button transparent onPress={() => this.props.navigation.goBack()}>
                <Icon name="arrow-left" size={25} color="#FFF" />
              </Button>
            </Left>
            <Right>
              <Button transparent onPress={() => Share.share({
                message: itemTittle + ' http://www.youtube.com/watch?v=' + itemId,
                url: 'http://www.youtube.com/watch?v=' + itemId,
                title: itemTittle
              }, {
                  // Android only:
                  dialogTitle: itemTittle,
                  // iOS only:
                  excludedActivityTypes: [
                    'com.apple.UIKit.activity.PostToTwitter'
                  ]
                })} >
                <Icon name="share-variant" size={25} color="#FFF" />
              </Button>
              <Button transparent
                onPress={() => { Linking.openURL('http://www.youtube.com/watch?v=' + itemId); }}>
                <Icon name="youtube-play" size={30} color="#FFF" />
              </Button>
            </Right>
          </Header>

          <Content refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={this._onRefresh.bind(this)}
            />

          }>
            <View
              style={{ width: width, height: Math.round(width * 9 / 16), }}
            />
            <View style={{
              backgroundColor: '#981A30',
            }} >
              <Text style={{
                color: '#fff',
                marginLeft: 20,
                marginTop: 5,
                marginBottom: 5,
                fontFamily: 'DBRegular',
                fontSize: 24,
              }}
              >{itemTittle}</Text>
            </View>
            <AdComponent adsManager={adsManager} />
            <Text style={styles.header}>คลิปเพิ่มเติมจาก NEW18</Text>
            <View style={{ backgroundColor: "#464646", height: 1 }} />
            <View style={{ backgroundColor: "#282828" }}>
              <FlatList
                data={this.state.Youtube}
                renderItem={({ item, index }) => <TouchableOpacity activeOpacity={1} onPress={() => navigate('YoutubeView', { itemId: item.id.videoId, itemTittle: item.snippet.title })}><Youtube item={item} index={index} /></TouchableOpacity>}
                keyExtractor={(item, index) => index}
              />
              <AdComponent adsManager={adsManager} />
            </View>
            <Text style={styles.header}>ข่าวเพิ่มเติมจาก NEW18</Text>
            <View style={{ backgroundColor: "#464646", height: 1 }} />
            <View style={{ backgroundColor: "#282828" }}>
              <FlatList
                data={this.state.data}
                renderItem={({ item, index }) => <TouchableOpacity activeOpacity={0.7} onPress={() => navigate('NHCardImage', { itemId: item.idnews, })}><TopNews item={item} index={index} /></TouchableOpacity>}
                keyExtractor={(item, index) => index}
              />
              <AdMini adsManager={adsManager} />
            </View>

            <View style={{ marginTop: 20, marginBottom: 20, justifyContent: 'center' }}>
              <Text style={{
                fontSize: 24,
                fontFamily: 'DBRegular',
                textAlign: 'center',
                color: '#FFF',
              }}>
                Copyright © 2561 | NEW18
                    </Text>
            </View>
          </Content>
        </Container>
      );
    }
    else {
      return (
        <Container style={{ backgroundColor: "#282828", }}>
          <Header style={{ backgroundColor: "#282828", }}>
            <StatusBar
              barStyle="light-content"
            />
            <Left>
              <Button transparent onPress={() => this.props.navigation.goBack()}>
                <Icon name="arrow-left" size={25} color="#FFF" />
              </Button>
            </Left>
            <Right>
              <Button transparent onPress={() => Share.share({
                message: itemTittle + ' http://www.youtube.com/watch?v=' + itemId,
                url: 'http://www.youtube.com/watch?v=' + itemId,
                title: itemTittle
              }, {
                  // Android only:
                  dialogTitle: itemTittle,
                  // iOS only:
                  excludedActivityTypes: [
                    'com.apple.UIKit.activity.PostToTwitter'
                  ]
                })} >
                <Icon name="share-variant" size={25} color="#FFF" />
              </Button>
              <Button transparent
                onPress={() => { Linking.openURL('http://www.youtube.com/watch?v=' + itemId); }}>
                <Icon name="youtube-play" size={30} color="#FFF" />
              </Button>
            </Right>
          </Header>

          <Content refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={this._onRefresh.bind(this)}
            />

          }>
            <Video
              source={{ uri: this.state.Video.url }}
              resizeMode="contain"
              onFullscreenUpdate={e => {this.setState({fullscreen: true}); console.log(this.state.fullscreen);}}
              style={{ width: width, height: Math.round(width * 9 / 16), }}
              shouldPlay
              useNativeControls
            />
            <View style={{
              backgroundColor: '#981A30',
            }} >
              <Text style={{
                color: '#fff',
                marginLeft: 20,
                marginTop: 5,
                marginBottom: 5,
                fontFamily: 'DBRegular',
                fontSize: 24,
              }}
              >{itemTittle}</Text>
            </View>
            <AdComponent adsManager={adsManager} />
            <Text style={styles.header}>คลิปเพิ่มเติมจาก NEW18</Text>
            <View style={{ backgroundColor: "#464646", height: 1 }} />
            <View style={{ backgroundColor: "#282828" }}>
              <FlatList
                data={this.state.Youtube}
                renderItem={({ item, index }) => <TouchableOpacity activeOpacity={1} onPress={this._onRefresh.bind(this, { itemId: item.id.videoId, itemTittle: item.snippet.title })}><Youtube item={item} index={index} /></TouchableOpacity>}
                keyExtractor={(item, index) => index}
              />
              <AdComponent adsManager={adsManager} />
            </View>
            <Text style={styles.header}>ข่าวเพิ่มเติมจาก NEW18</Text>
            <View style={{ backgroundColor: "#464646", height: 1 }} />
            <View style={{ backgroundColor: "#282828" }}>
              <FlatList
                data={this.state.data}
                renderItem={({ item, index }) => <TouchableOpacity activeOpacity={0.7} onPress={() => navigate('NHCardImage', { itemId: item.idnews, })}><TopNews item={item} index={index} /></TouchableOpacity>}
                keyExtractor={(item, index) => index}
              />
              <AdMini adsManager={adsManager} />
            </View>

            <View style={{ marginTop: 20, marginBottom: 20, justifyContent: 'center' }}>
              <Text style={{
                fontSize: 24,
                fontFamily: 'DBRegular',
                textAlign: 'center',
                color: '#FFF',
              }}>
                Copyright © 2561 | NEW18
                    </Text>
            </View>
          </Content>
        </Container>
      );
    }
  }
}

export default YoutubeView;
